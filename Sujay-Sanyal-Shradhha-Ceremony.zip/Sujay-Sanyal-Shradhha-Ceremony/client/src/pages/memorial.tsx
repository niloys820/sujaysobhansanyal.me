import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Heart, ChevronLeft, ChevronRight } from "lucide-react";
import type { Ceremony } from "@shared/schema";


import { useState, useEffect } from "react";

// Vimeo Player API type declaration
interface VimeoPlayer {
  on: (event: string, callback: () => void) => void;
  requestFullscreen: () => Promise<void>;
}

interface VimeoAPI {
  Player: new (element: HTMLElement | string, options?: any) => VimeoPlayer;
}

declare global {
  interface Window {
    Vimeo?: VimeoAPI;
  }
}

// Emotional color palettes
const colorPalettes = {
  peaceful: {
    name: "Peaceful",
    primary: "hsl(210, 20%, 98%)",
    secondary: "hsl(210, 40%, 95%)",
    accent: "hsl(210, 50%, 85%)",
    text: "hsl(210, 15%, 25%)",
    textLight: "hsl(210, 10%, 45%)",
    background: "hsl(210, 30%, 98%)"
  },
  reflective: {
    name: "Reflective", 
    primary: "hsl(240, 15%, 96%)",
    secondary: "hsl(240, 20%, 92%)",
    accent: "hsl(240, 30%, 80%)",
    text: "hsl(240, 20%, 20%)",
    textLight: "hsl(240, 15%, 40%)",
    background: "hsl(240, 25%, 97%)"
  },
  hopeful: {
    name: "Hopeful",
    primary: "hsl(45, 40%, 96%)",
    secondary: "hsl(45, 50%, 90%)",
    accent: "hsl(45, 60%, 75%)",
    text: "hsl(45, 30%, 15%)",
    textLight: "hsl(45, 25%, 35%)",
    background: "hsl(45, 45%, 98%)"
  },
  warm: {
    name: "Warm",
    primary: "hsl(25, 35%, 95%)",
    secondary: "hsl(25, 45%, 88%)",
    accent: "hsl(25, 55%, 70%)",
    text: "hsl(25, 25%, 20%)",
    textLight: "hsl(25, 20%, 40%)",
    background: "hsl(25, 40%, 97%)"
  },
  serene: {
    name: "Serene",
    primary: "hsl(180, 25%, 96%)",
    secondary: "hsl(180, 35%, 90%)",
    accent: "hsl(180, 45%, 75%)",
    text: "hsl(180, 20%, 20%)",
    textLight: "hsl(180, 15%, 40%)",
    background: "hsl(180, 30%, 98%)"
  }
};

// Function to determine mood from quote content
const detectQuoteMood = (quote: string): keyof typeof colorPalettes => {
  const lowerQuote = quote.toLowerCase();
  
  // Keywords for different moods
  const moodKeywords = {
    peaceful: ['peace', 'calm', 'quiet', 'still', 'rest', 'gentle', 'soft'],
    reflective: ['memory', 'remember', 'think', 'reflect', 'past', 'moments', 'time'],
    hopeful: ['hope', 'future', 'dream', 'light', 'bright', 'tomorrow', 'believe'],
    warm: ['love', 'heart', 'family', 'together', 'warmth', 'care', 'embrace'],
    serene: ['nature', 'sky', 'water', 'eternal', 'infinite', 'beyond', 'spirit']
  };
  
  // Check for mood keywords
  for (const [mood, keywords] of Object.entries(moodKeywords)) {
    if (keywords.some(keyword => lowerQuote.includes(keyword))) {
      return mood as keyof typeof colorPalettes;
    }
  }
  
  // Default to peaceful
  return 'peaceful';
};

export default function Memorial() {
  const { data: ceremony, isLoading, error } = useQuery<Ceremony>({
    queryKey: ["/api/ceremony"],
  });

  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
  const [currentPalette, setCurrentPalette] = useState<keyof typeof colorPalettes>('peaceful');

  // Update color palette when quote changes
  useEffect(() => {
    if (ceremony?.quotes && ceremony.quotes[currentQuoteIndex]) {
      const newMood = detectQuoteMood(ceremony.quotes[currentQuoteIndex]);
      setCurrentPalette(newMood);
    }
  }, [ceremony?.quotes, currentQuoteIndex]);

  // Vimeo player fullscreen functionality
  useEffect(() => {
    const setupVimeoPlayer = () => {
      // Check if Vimeo Player API is available
      if (typeof window !== 'undefined' && window.Vimeo) {
        const iframe = document.getElementById('vimeo-player');
        if (iframe) {
          const player = new window.Vimeo.Player(iframe);
          
          // Listen for play event and enter fullscreen
          player.on('play', () => {
            player.requestFullscreen().catch((error: any) => {
              // Fallback if fullscreen is not supported or blocked
              console.log('Fullscreen not available:', error);
            });
          });
        }
      }
    };

    // Wait for Vimeo API to load
    if (typeof window !== 'undefined') {
      if (window.Vimeo) {
        setupVimeoPlayer();
      } else {
        // Poll for Vimeo API availability
        const checkVimeo = setInterval(() => {
          if (window.Vimeo) {
            setupVimeoPlayer();
            clearInterval(checkVimeo);
          }
        }, 100);

        // Clean up interval after 5 seconds
        setTimeout(() => clearInterval(checkVimeo), 5000);
      }
    }
  }, [ceremony]);

  // Auto-advance carousel every 10 seconds
  useEffect(() => {
    if (!ceremony?.quotes || ceremony.quotes.length <= 1) return;
    
    const timeout = setTimeout(() => {
      setCurrentQuoteIndex((prev) => (prev + 1) % ceremony.quotes.length);
    }, 10000); // 10 seconds

    return () => clearTimeout(timeout);
  }, [ceremony?.quotes, currentQuoteIndex]);

  const nextQuote = () => {
    if (!ceremony?.quotes) return;
    setCurrentQuoteIndex((prev) => (prev + 1) % ceremony.quotes.length);
  };

  const prevQuote = () => {
    if (!ceremony?.quotes) return;
    setCurrentQuoteIndex((prev) => (prev - 1 + ceremony.quotes.length) % ceremony.quotes.length);
  };



  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-memorial-50 to-memorial-200 flex items-center justify-center">
        <div className="text-memorial-600">Loading memorial information...</div>
      </div>
    );
  }

  if (error || !ceremony) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-memorial-50 to-memorial-200 flex items-center justify-center">
        <Card className="p-6 max-w-md mx-4">
          <div className="text-center text-memorial-600">
            <p className="mb-4">Unable to load memorial information</p>
            <p className="text-sm">Please try again later</p>
          </div>
        </Card>
      </div>
    );
  }

  const palette = colorPalettes[currentPalette];

  return (
    <div 
      className="min-h-screen safe-area-inset transition-all duration-1000 ease-in-out"
      style={{
        background: `linear-gradient(135deg, ${palette.background} 0%, ${palette.secondary} 100%)`,
        color: palette.text
      }}
    >
      <div className="mobile-container space-y-4 sm:space-y-6">
        
        {/* Page Header */}
        <div className="text-center pt-2 sm:pt-4 pb-2">
          <h1 
            className="responsive-text-2xl font-bold mb-2 transition-colors duration-1000"
            style={{ color: palette.text }}
          >
            In Loving Memory of <span className="whitespace-nowrap">{ceremony.person}</span>
          </h1>
          <p 
            className="responsive-text-base transition-colors duration-1000"
            style={{ color: palette.textLight }}
          >
            July 10, 1938 to June 03, 2025
          </p>
        </div>
        
        {/* Quote Carousel Hero Section */}
        {ceremony.quotes && ceremony.quotes.length > 0 && (
          <Card 
            className="shadow-xl transition-all duration-1000 ease-in-out"
            style={{
              backgroundColor: palette.primary,
              borderColor: palette.accent,
              borderWidth: '1px'
            }}
          >
            <div className="p-4 sm:p-6 lg:p-8 text-center">
              <div className="min-h-[120px] sm:min-h-[140px] lg:min-h-[160px] flex items-center justify-center px-4 sm:px-8">
                <div className="text-center max-w-full">
                  <blockquote 
                    className="italic responsive-text-base leading-relaxed mb-3 sm:mb-4 transition-colors duration-1000"
                    style={{ color: palette.text }}
                  >
                    "{ceremony.quotes[currentQuoteIndex]}"
                  </blockquote>
                  <p 
                    className="responsive-text-sm font-medium transition-colors duration-1000"
                    style={{ color: palette.textLight }}
                  >
                    – {ceremony.quoteAuthors?.[currentQuoteIndex] || 'Unknown'}
                  </p>
                </div>
              </div>

              {ceremony.quotes.length > 1 && (
                <div className="flex justify-between items-center mt-4 sm:mt-6 mb-2">
                  <button
                    onClick={prevQuote}
                    className="touch-button w-10 h-10 sm:w-11 sm:h-11 rounded-full touch-action-manipulation transition-all duration-300"
                    style={{
                      backgroundColor: palette.secondary,
                      color: palette.text,
                      border: `1px solid ${palette.accent}`
                    }}
                    aria-label="Previous quote"
                  >
                    <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
                  </button>
                  
                  <div className="flex justify-center space-x-2">
                    {ceremony.quotes.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentQuoteIndex(index)}
                        className="touch-button w-1 h-1 sm:w-1.5 sm:h-1.5 lg:w-1 lg:h-1 rounded-full transition-all duration-300 touch-action-manipulation"
                        style={{
                          backgroundColor: index === currentQuoteIndex ? palette.accent : palette.secondary,
                          opacity: index === currentQuoteIndex ? 1 : 0.6
                        }}
                        aria-label={`Go to quote ${index + 1}`}
                      />
                    ))}
                  </div>
                  
                  <button
                    onClick={nextQuote}
                    className="touch-button w-10 h-10 sm:w-11 sm:h-11 rounded-full touch-action-manipulation transition-all duration-300"
                    style={{
                      backgroundColor: palette.secondary,
                      color: palette.text,
                      border: `1px solid ${palette.accent}`
                    }}
                    aria-label="Next quote"
                  >
                    <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
                  </button>
                </div>
              )}
            </div>
          </Card>
        )}
        


        {/* Memorial Video Hero Section */}
        <Card 
          className="overflow-hidden shadow-xl transition-all duration-1000"
          style={{
            backgroundColor: palette.primary,
            borderColor: palette.accent,
            borderWidth: '1px'
          }}
        >
          <div 
            className="p-4 sm:p-6 lg:p-8 text-center transition-colors duration-1000"
            style={{ backgroundColor: palette.primary }}
          >
            <h2 
              className="responsive-text-lg font-semibold mb-4 transition-colors duration-1000"
              style={{ color: palette.text }}
            >
              Story of My Beloved Father - Narrated In His Own Voice
            </h2>
            
            <div className="w-full max-w-4xl mx-auto">
              <div 
                className="relative w-full rounded-lg overflow-hidden shadow-lg transition-all duration-1000"
                style={{ 
                  backgroundColor: palette.secondary,
                  borderColor: palette.accent,
                  borderWidth: '2px'
                }}
              >
                {/* Vimeo Memorial Video */}
                <div style={{padding:'56.25% 0 0 0', position:'relative'}}>
                  <iframe 
                    id="vimeo-player"
                    src="https://player.vimeo.com/video/1093486595?badge=0&autopause=0&player_id=0&app_id=58479&controls=1&title=0&byline=0&portrait=0&outro=0&suggested=0&loop=1&v=1" 
                    frameBorder="0" 
                    allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share" 
                    style={{position:'absolute', top:0, left:0, width:'100%', height:'100%'}} 
                    title="Story of My Beloved Father - Sujay Sobhan Sanyal"
                    className="rounded-lg"
                  />
                </div>
              </div>
            </div>
            
            <p 
              className="responsive-text-sm mt-4 transition-colors duration-1000 max-w-2xl mx-auto"
              style={{ color: palette.textLight }}
            >
              A celebration of Sujay Sobhan Sanyal's life and the beautiful memories shared during the memorial service on Sunday, June 15, 2025.
            </p>
          </div>
        </Card>



        {/* Footer */}
        <div 
          className="text-center responsive-text-xs py-4 sm:py-6 transition-colors duration-1000"
          style={{ color: palette.textLight }}
        >
          <p>With love and remembrance</p>
        </div>
        
      </div>
    </div>
  );
}

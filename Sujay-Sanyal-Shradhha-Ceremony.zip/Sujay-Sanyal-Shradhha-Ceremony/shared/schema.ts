import { pgTable, text, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const ceremonies = pgTable("ceremonies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  person: text("person").notNull(),
  dates: text("dates").notNull(),
  ceremonyDate: text("ceremony_date").notNull(),
  time: text("time").notNull(),
  venueName: text("venue_name").notNull(),
  venueAddress: text("venue_address").notNull(),
  quotes: text("quotes").array().notNull(),
  quoteAuthors: text("quote_authors").array().notNull(),
});

export const insertCeremonySchema = createInsertSchema(ceremonies).omit({
  id: true,
});

export type InsertCeremony = z.infer<typeof insertCeremonySchema>;
export type Ceremony = typeof ceremonies.$inferSelect;

// Keep existing users table for compatibility
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

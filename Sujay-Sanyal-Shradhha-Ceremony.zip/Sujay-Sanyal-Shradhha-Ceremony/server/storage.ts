import { users, ceremonies, type User, type InsertUser, type Ceremony, type InsertCeremony } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getCeremony(): Promise<Ceremony | undefined>;
  createCeremony(ceremony: InsertCeremony): Promise<Ceremony>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private ceremonies: Map<number, Ceremony>;
  private currentUserId: number;
  private currentCeremonyId: number;

  constructor() {
    this.users = new Map();
    this.ceremonies = new Map();
    this.currentUserId = 1;
    this.currentCeremonyId = 1;

    // Initialize with the memorial ceremony data
    this.initializeCeremonyData();
  }

  private initializeCeremonyData() {
    const ceremonyData: Ceremony = {
      id: 1,
      title: 'Shradhha Ceremony',
      person: 'Sujay Sobhan Sanyal',
      dates: 'July 10, 1938 - June 3, 2025',
      ceremonyDate: 'Sunday June 15, 2025',
      time: '11am onwards',
      venueName: 'Raajkutir',
      venueAddress: '89C, Maulana Abdul Kalam Azad Sarani, Phool Bagan, Kankurgachi, Kolkata, West Bengal 700054',
      quotes: [
        'The essence of human birth is living for others. When we realize and adopt this in our daily life, then life truly becomes easy – we are then truly alive.',
        'A good laugh and a long sleep are the two best cures for everything',
        'Do everything you have to do, but do not do it with greed, not with ego, not with lust nor with envy, but with love, compassion, humility and devotion',
        'Your right is to work only, but never to the fruit thereof. Be not instrumental in making your action bear fruit, do not let your attachment lead to inaction. Perform your duties renouncing attachments and even tempered in success and failures, evenness of temper is called yoga',
        'When your mind will have fully crossed the mire of delusions, you will then grow indifferent to the enjoyment of the world and the next',
        'A balanced and unperturbed mind in all conditions, situations and circumstances and mind devoid of attachment and anger attains peace and happiness'
      ],
      quoteAuthors: [
        'Sujay Sobhan Sanyal',
        'Sujay Sobhan Sanyal',
        'Sujay Sobhan Sanyal',
        'Sujay Sobhan Sanyal',
        'Sujay Sobhan Sanyal',
        'Sujay Sobhan Sanyal'
      ]
    };
    
    this.ceremonies.set(1, ceremonyData);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCeremony(): Promise<Ceremony | undefined> {
    return this.ceremonies.get(1);
  }

  async createCeremony(insertCeremony: InsertCeremony): Promise<Ceremony> {
    const id = this.currentCeremonyId++;
    const ceremony: Ceremony = { ...insertCeremony, id };
    this.ceremonies.set(id, ceremony);
    return ceremony;
  }
}

export const storage = new MemStorage();

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get ceremony information
  app.get("/api/ceremony", async (req, res) => {
    try {
      const ceremony = await storage.getCeremony();
      if (!ceremony) {
        return res.status(404).json({ message: "Ceremony information not found" });
      }
      res.json(ceremony);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ceremony information" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({
      status: 'Memorial ceremony page operational',
      ceremony: 'Sujay Sobhan Sanyal Shradhha',
      timestamp: new Date().toISOString()
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
